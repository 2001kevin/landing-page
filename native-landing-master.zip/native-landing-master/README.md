# Landing Page
Simple manual landing page by M. Nur Fawaiq (2015)


Tutorial pemrograman lengkap step by step : https://yukcoding.github.io
